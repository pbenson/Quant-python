class PriceSeries(object):
    def __init__(self, tckr, prices):
        self.ticker = tckr
        self.price_series = prices

    def __repr__(self):
        return 'PriceSeries(' + self.ticker + ') ' \
               + str(len(self.price_series)) + ' prices'