# print('hello, world')

import csv
import monte_carlo as mc

with open('AMZN_GOOG_AAPL.csv', 'r') as csvfile:
    price_reader = csv.reader(csvfile, delimiter=',')
    on_first_row = True
    all_price_series = []
    for row in price_reader:
        if on_first_row:
            tickers = row[1:]
            ticker_to_prices_dict = {ticker: [] for ticker in tickers}
            on_first_row = False
        else:
            prices = row[1:]
            for ticker, price in zip(tickers, prices):
                ticker_to_prices_dict[ticker].append(float(price))
    for ticker, prices in ticker_to_prices_dict.items():
        all_price_series.append(mc.PriceSeries(ticker, prices))
    all_price_series




